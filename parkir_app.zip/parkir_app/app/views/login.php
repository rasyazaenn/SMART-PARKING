<!DOCTYPE html>
<html>
<head>
    <title>Login Parkir</title>

    <style>
        body {
            margin: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #f5f6fa;
            font-family: Arial, sans-serif;
        }

        .login-container {
            display: flex;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            align-items: center;
        }

        .logo {
            margin-right: 30px;
        }

        .logo img {
            width: 160px;
        }

        h2 {
            margin-top: 0;
        }

        input {
            width: 220px;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background: black;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #333;
        }
    </style>
</head>
<body>

    <div class="login-container">

        <!-- LOGO KIRI -->
        <div class="logo">
            <img src="logo.png">
        </div>

        <!-- FORM ASLI KAMU (TIDAK DIUBAH) -->
        <div>
            <h2>Login Parqo</h2>

            <form method="POST" action="index.php?url=auth/login">
                <input type="text" name="username" placeholder="Username"><br>
                <input type="password" name="password" placeholder="Password"><br>
                <button type="submit">Login</button>
            </form>
        </div>

    </div>

</body>
</html>